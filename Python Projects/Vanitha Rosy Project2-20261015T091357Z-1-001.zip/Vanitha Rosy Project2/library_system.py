"""
Simple Library Management System
Using only lists and dictionaries
"""

# Global variables
books = {}  # Dictionary to store books: book_id -> book details
issued_books = {}  # Dictionary to store issued books: book_id -> student_name
book_id_counter = 1  # To generate unique book IDs

def display_menu():
    """Display the main menu"""
    print("\n" + "="*50)
    print("📚 LIBRARY MANAGEMENT SYSTEM")
    print("="*50)
    print("1. Add New Book")
    print("2. Display All Books")
    print("3. Search Book")
    print("4. Update Book Details")
    print("5. Delete Book")
    print("6. Issue Book")
    print("7. Return Book")
    print("8. Display Available Books")
    print("9. Display Issued Books")
    print("10. Exit")
    print("="*50)

def add_book():
    """Add a new book to the library"""
    global book_id_counter
    
    print("\n--- ADD NEW BOOK ---")
    title = input("Enter Book Title: ")
    author = input("Enter Author Name: ")
    genre = input("Enter Genre: ")
    year = input("Enter Publication Year: ")
    
    # Generate book ID
    book_id = str(book_id_counter)
    book_id_counter += 1
    
    # Store book details
    books[book_id] = {
        'title': title,
        'author': author,
        'genre': genre,
        'year': year,
        'available': True  # True means available, False means issued
    }
    
    print(f"✅ Book added successfully! Book ID: {book_id}")

def display_all_books():
    """Display all books in the library with proper formatting"""
    print("\n--- ALL BOOKS ---")
    
    if not books:
        print("No books in the library.")
        return
    
    # Print header with proper spacing
    print(f"{'ID':<6} {'Title':<30} {'Author':<25} {'Status':<10}")
    print("-" * 75)
    
    for book_id, details in books.items():
        status = "Available" if details['available'] else "Issued"
        # Truncate long titles and authors to fit in columns
        title = details['title'][:28] + ".." if len(details['title']) > 28 else details['title']
        author = details['author'][:23] + ".." if len(details['author']) > 23 else details['author']
        print(f"{book_id:<6} {title:<30} {author:<25} {status:<10}")

def search_book():
    """Search for a book"""
    print("\n--- SEARCH BOOK ---")
    print("1. Search by Book ID")
    print("2. Search by Book Title")
    print("3. Search by Author")
    
    choice = input("Enter your choice (1-3): ")
    
    if choice == '1':
        book_id = input("Enter Book ID: ")
        if book_id in books:
            display_book_details(book_id)
        else:
            print("❌ Book not found!")
    
    elif choice == '2':
        title = input("Enter Book Title: ").lower()
        found = False
        for book_id, details in books.items():
            if title in details['title'].lower():
                display_book_details(book_id)
                found = True
        if not found:
            print("❌ No books found with this title!")
    
    elif choice == '3':
        author = input("Enter Author Name: ").lower()
        found = False
        for book_id, details in books.items():
            if author in details['author'].lower():
                display_book_details(book_id)
                found = True
        if not found:
            print("❌ No books found by this author!")
    
    else:
        print("❌ Invalid choice!")

def display_book_details(book_id):
    """Display details of a specific book"""
    details = books[book_id]
    print("\n--- BOOK DETAILS ---")
    print(f"Book ID: {book_id}")
    print(f"Title: {details['title']}")
    print(f"Author: {details['author']}")
    print(f"Genre: {details['genre']}")
    print(f"Year: {details['year']}")
    print(f"Status: {'Available' if details['available'] else 'Issued'}")
    
    # Check if book is issued
    if book_id in issued_books:
        print(f"Issued to: {issued_books[book_id]}")

def update_book():
    """Update book details"""
    print("\n--- UPDATE BOOK ---")
    book_id = input("Enter Book ID to update: ")
    
    if book_id not in books:
        print("❌ Book not found!")
        return
    
    print("Leave blank to keep current value")
    details = books[book_id]
    
    new_title = input(f"Title ({details['title']}): ")
    if new_title:
        details['title'] = new_title
    
    new_author = input(f"Author ({details['author']}): ")
    if new_author:
        details['author'] = new_author
    
    new_genre = input(f"Genre ({details['genre']}): ")
    if new_genre:
        details['genre'] = new_genre
    
    new_year = input(f"Year ({details['year']}): ")
    if new_year:
        details['year'] = new_year
    
    print("✅ Book updated successfully!")

def delete_book():
    """Delete a book from the library"""
    print("\n--- DELETE BOOK ---")
    book_id = input("Enter Book ID to delete: ")
    
    if book_id not in books:
        print("❌ Book not found!")
        return
    
    if book_id in issued_books:
        print("❌ Cannot delete: Book is currently issued!")
        return
    
    confirm = input(f"Are you sure you want to delete '{books[book_id]['title']}'? (y/n): ")
    if confirm.lower() == 'y':
        del books[book_id]
        print("✅ Book deleted successfully!")
    else:
        print("❌ Deletion cancelled!")

def issue_book():
    """Issue a book to a student"""
    print("\n--- ISSUE BOOK ---")
    book_id = input("Enter Book ID to issue: ")
    
    if book_id not in books:
        print("❌ Book not found!")
        return
    
    if not books[book_id]['available']:
        print("❌ Book is already issued!")
        return
    
    student_name = input("Enter Student Name: ")
    
    # Mark as issued
    books[book_id]['available'] = False
    issued_books[book_id] = student_name
    
    print(f"✅ Book issued successfully to {student_name}!")

def return_book():
    """Return an issued book"""
    print("\n--- RETURN BOOK ---")
    book_id = input("Enter Book ID to return: ")
    
    if book_id not in books:
        print("❌ Book not found!")
        return
    
    if book_id not in issued_books:
        print("❌ This book was not issued!")
        return
    
    student_name = issued_books[book_id]
    
    # Mark as returned
    books[book_id]['available'] = True
    del issued_books[book_id]
    
    print(f"✅ Book returned successfully from {student_name}!")

def display_available_books():
    """Display only available books with proper formatting"""
    print("\n--- AVAILABLE BOOKS ---")
    
    available_books = []
    for book_id, details in books.items():
        if details['available']:
            available_books.append((book_id, details))
    
    if not available_books:
        print("No books available!")
        return
    
    print(f"{'ID':<6} {'Title':<30} {'Author':<25}")
    print("-" * 65)
    
    for book_id, details in available_books:
        title = details['title'][:28] + ".." if len(details['title']) > 28 else details['title']
        author = details['author'][:23] + ".." if len(details['author']) > 23 else details['author']
        print(f"{book_id:<6} {title:<30} {author:<25}")

def display_issued_books():
    """Display all issued books with proper formatting"""
    print("\n--- ISSUED BOOKS ---")
    
    if not issued_books:
        print("No books are currently issued!")
        return
    
    print(f"{'ID':<6} {'Title':<30} {'Issued To':<25}")
    print("-" * 65)
    
    for book_id, student in issued_books.items():
        title = books[book_id]['title'][:28] + ".." if len(books[book_id]['title']) > 28 else books[book_id]['title']
        student_name = student[:23] + ".." if len(student) > 23 else student
        print(f"{book_id:<6} {title:<30} {student_name:<25}")

def add_sample_books():
    """Add some sample books for testing"""
    global book_id_counter
    
    sample_data = [
        ("Python Programming", "John Smith", "Technology", "2021"),
        ("Data Structures and Algorithms", "Robert Johnson", "Computer Science", "2020"),
        ("Introduction to Machine Learning", "Sarah Williams", "AI/ML", "2022"),
        ("Database Management Systems", "Michael Brown", "Database", "2019"),
        ("Web Development with Django", "Emily Davis", "Web Dev", "2021"),
        ("Clean Code: A Handbook", "Robert C. Martin", "Programming", "2008"),
        ("Design Patterns", "Erich Gamma", "Software Design", "1994"),
        ("Network Security", "William Stallings", "Security", "2017"),
        ("Introduction to Algorithms", "Thomas H. Cormen", "Computer Science", "2009"),
        ("Artificial Intelligence", "Stuart Russell", "AI", "2010")
    ]
    
    for title, author, genre, year in sample_data:
        book_id = str(book_id_counter)
        book_id_counter += 1
        books[book_id] = {
            'title': title,
            'author': author,
            'genre': genre,
            'year': year,
            'available': True
        }
    
    print(f"✅ Added {len(sample_data)} sample books!")

# Main program
def main():
    """Main program loop"""
    print("🌟 WELCOME TO LIBRARY MANAGEMENT SYSTEM 🌟")
    
    # Add some sample books
    add_sample_books()
    
    while True:
        display_menu()
        choice = input("Enter your choice (1-10): ")
        
        if choice == '1':
            add_book()
        elif choice == '2':
            display_all_books()
        elif choice == '3':
            search_book()
        elif choice == '4':
            update_book()
        elif choice == '5':
            delete_book()
        elif choice == '6':
            issue_book()
        elif choice == '7':
            return_book()
        elif choice == '8':
            display_available_books()
        elif choice == '9':
            display_issued_books()
        elif choice == '10':
            print("👋 Thank you for using Library Management System!")
            print("Goodbye!")
            break
        else:
            print("❌ Invalid choice! Please select 1-10.")
        
        input("\nPress Enter to continue...")

# Run the program
if __name__ == "__main__":
    main()